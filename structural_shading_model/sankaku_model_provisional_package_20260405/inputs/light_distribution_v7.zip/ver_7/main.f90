program main_greenhouse
  use greenhouse_module
  implicit none

  ! 変数宣言
  real(dp_kind) :: unit_w, gutter_w, gutter_d, gutter_top
  real(dp_kind) :: x_low, x_up, y_low, y_up, z_low, z_up
  integer :: nx, ny, nz
  integer :: day, month, hour, minute, month_modulo, date 
  real(dp_kind) :: th_deg, ph_deg
  real(dp_kind) :: I0v, trans_at, trans_cov, I_diff
  real(dp_kind), allocatable :: illum(:,:,:), illum_sum(:,:,:)
  real(dp_kind), allocatable :: final_illum(:,:)
  real(dp_kind) :: latitude, longitude, localtime, norm
  ! 柱のパラメータ（旧 period_val_pillar → period_val_y）
  real(dp_kind) :: pillar_width, period_val_y
  ! カーテンのパラメータ
  real(dp_kind) :: curtain1_width, curtain1_thickness
  real(dp_kind) :: curtain2_width, curtain2_thickness

  ! --- 入力値の設定 ---
  unit_w     = 7.5_dp_kind
  gutter_w   = 0.60_dp_kind
  gutter_d   = 0.10_dp_kind      ! 雨樋の厚み（z方向）
  gutter_top = 4.0_dp_kind
  pillar_width = 0.2_dp_kind      ! 柱幅（x方向）
  period_val_y = 3.0_dp_kind      ! 柱の y方向周期

  ! カーテン1, カーテン2の寸法設定（例）
  curtain1_width     = 0.70_dp_kind    ! カーテン1のx方向幅
  curtain1_thickness = 0.05_dp_kind   ! カーテン1のz方向厚み
  curtain2_width     = 0.70_dp_kind    ! カーテン2のx方向幅
  curtain2_thickness = 0.05_dp_kind   ! カーテン2のz方向厚み

  ! 計算領域の設定
  x_low = 0.0_dp_kind;  x_up = unit_w
  y_low = 0.0_dp_kind;  y_up = 3.0_dp_kind  
  z_low = 0.0_dp_kind;  z_up = 5.0_dp_kind
  nx = 76; ny = 31; nz = 41
  allocate(illum(nx,ny,nz), illum_sum(nx,ny,nz))

  I0v     = 1.0_dp_kind
  trans_at = 1.0_dp_kind
  trans_cov = 1.0_dp_kind
  I_diff  = 0.0_dp_kind

  ! --- 地理情報の設定 ---
  longitude = 136.0d0 + (44.0/60.0) + (2.0/(60.0*60.0))
  latitude  = 35.0d0 + (4.0/60.0) + (21.0/(60.0*60.0))
  
  illum_sum = 0.0_dp_kind
  do month = 12, 14 
    month_modulo = mod(month,12)
    if (month_modulo == 0) month_modulo = 12
    do day = 1, daymax(month_modulo)    
      date = day_of_year(month_modulo, day)
write(*,*) "day: ", date
      do hour = 4, 20
        do minute = 0, 58, 2  !
          localtime = dble(hour) + dble(minute)/60.0_dp_kind
          call SunPosition(latitude, longitude, date, localtime, th_deg, ph_deg)
          if (th_deg < 0.0_dp_kind) cycle  ! 夜間はスキップ
          illum = 0.0_dp_kind
          call greenhouse_calc(unit_w, gutter_w, gutter_d, gutter_top, &
                               x_low, x_up, y_low, y_up, z_low, z_up, nx, ny, nz, &
                               th_deg, ph_deg, I0v, trans_at, trans_cov, I_diff, &
                               pillar_width, period_val_y, curtain1_width, curtain1_thickness, &
                               curtain2_width, curtain2_thickness, illum)
          illum_sum = illum_sum + illum
        end do
      end do
    end do
  end do

  ! --- y方向の平均化（2次元配列へ変換） ---
  allocate(final_illum(nx,nz))
  final_illum = sum(illum_sum, dim=2) / real(ny, dp_kind)

  ! --- 正規化 ---
  norm = maxval(final_illum)
  final_illum = final_illum / norm

  ! --- 2次元配列の出力 ---
  call output_illum_2d(final_illum, nx, nz, x_low, x_up, z_low, z_up)

  deallocate(illum, illum_sum, final_illum)
  
end program main_greenhouse


