module greenhouse_module
  implicit none
  integer, parameter :: dp_kind = kind(1.0d0)
contains

  !--------------------------------------------------------------------
  ! サブルーチン greenhouse_calc
  !
  ! 入力引数:
  !   unit_width        : 温室棟の東西幅（棟間口, m）
  !   gutter_width      : 雨樋の横幅 (m)
  !   gutter_depth      : 雨樋の厚み (z方向, m) ←これまでのdepth
  !   gutter_ztop       : 雨樋上端位置 (m)
  !   x_low,x_up        : 計算領域の x 座標範囲 (m)
  !   y_low,y_up        : 計算領域の y 座標範囲 (m)
  !   z_low,z_up        : 計算領域の z 座標範囲 (m)
  !   nx,ny,nz          : 各方向のグリッド点数
  !   theta_deg,phi_deg : 太陽高度角・方位角（度）
  !   I0_val            : 太陽定数 (W/m^2)
  !   trans_atmos       : 大気減衰係数 (0～1)
  !   trans_cover       : ビニールカバー透過率 (0～1)
  !   I_diffuse         : 拡散光 (W/m^2)
  !   pillar_width      : 柱の幅 (x方向, m)
  !   period_val_y      : 柱の y 軸方向の周期 (m)  ※旧 period_val_pillar
  !   curtain1_width    : カーテン１の横幅 (m)
  !   curtain1_thickness: カーテン１の厚み (z方向, m)
  !   curtain2_width    : カーテン２の横幅 (m)
  !   curtain2_thickness: カーテン２の厚み (z方向, m)
  !
  ! 出力引数:
  !   illum             : 各グリッド点での受光量 (W/m^2) の 3次元配列 (nx,ny,nz)
  !--------------------------------------------------------------------
  subroutine greenhouse_calc(unit_width, gutter_width, gutter_depth, gutter_ztop, &
                             x_low, x_up, y_low, y_up, z_low, z_up, nx, ny, nz, &
                             theta_deg, phi_deg, I0_val, trans_atmos, trans_cover, I_diffuse, &
                             pillar_width, period_val_y, curtain1_width, curtain1_thickness, &
                             curtain2_width, curtain2_thickness, illum)
    implicit none
    ! 入力引数
    real(dp_kind), intent(in) :: unit_width
    real(dp_kind), intent(in) :: gutter_width
    real(dp_kind), intent(in) :: gutter_depth
    real(dp_kind), intent(in) :: gutter_ztop
    real(dp_kind), intent(in) :: x_low, x_up
    real(dp_kind), intent(in) :: y_low, y_up
    real(dp_kind), intent(in) :: z_low, z_up
    integer, intent(in)       :: nx, ny, nz
    real(dp_kind), intent(in) :: theta_deg, phi_deg
    real(dp_kind), intent(in) :: I0_val
    real(dp_kind), intent(in) :: trans_atmos
    real(dp_kind), intent(in) :: trans_cover
    real(dp_kind), intent(in) :: I_diffuse
    real(dp_kind), intent(in) :: pillar_width
    real(dp_kind), intent(in) :: period_val_y
    real(dp_kind), intent(in) :: curtain1_width, curtain1_thickness
    real(dp_kind), intent(in) :: curtain2_width, curtain2_thickness
    ! 出力引数
    real(dp_kind), allocatable, intent(out) :: illum(:,:,:)
    
    ! ローカル変数
    integer :: ix, iy, iz, cand_loop, candidate, region
    integer :: shadow_curtain, shadow_pillar, shadow_flag
    real(dp_kind) :: dx, dy, dz, tol
    real(dp_kind) :: grid_x, grid_y, grid_z
    real(dp_kind) :: sun_theta, sun_phi
    real(dp_kind), dimension(3) :: sun_dir
    real(dp_kind) :: I_direct
    real(dp_kind) :: period_val_x
    real(dp_kind) :: t_left, t_right, t_bottom
    real(dp_kind) :: x_bottom, z_left, z_right
    real(dp_kind) :: region_x_left, region_x_right, region_z_top, region_z_bottom

    ! --- 柱用変数 ---
    integer :: offset_x, offset_y, candidate_x, candidate_y
    real(dp_kind) :: cand_x, cand_y, t_p, x_int, z_int

    tol = 1.0e-6_dp_kind
    period_val_x = unit_width

    dx = (x_up - x_low) / real(nx - 1, dp_kind)
    dy = (y_up - y_low) / real(ny - 1, dp_kind)
    dz = (z_up - z_low) / real(nz - 1, dp_kind)

    sun_theta = theta_deg * (acos(-1.0_dp_kind)/180.0_dp_kind)
    sun_phi   = phi_deg   * (acos(-1.0_dp_kind)/180.0_dp_kind)
    sun_dir(1) = cos(sun_theta)*sin(sun_phi)
    sun_dir(2) = cos(sun_theta)*cos(sun_phi)
    sun_dir(3) = sin(sun_theta)

    I_direct = I0_val * trans_atmos * trans_cover * sin(sun_theta)

    allocate(illum(nx,ny,nz))
    illum = 0.0_dp_kind


!    GOTO 900



    !==== 各グリッド点について遮蔽判定 ====
    do iz = 1, nz
      grid_z = z_low + (iz-1)*dz
      do iy = 1, ny
        grid_y = y_low + (iy-1)*dy
        do ix = 1, nx
          grid_x = x_low + (ix-1)*dx


          !----- カーテン群（雨樋＋カーテン１＋カーテン２）の遮蔽判定 -----
          shadow_curtain = 0
          if ( abs(sun_dir(1)) > tol .and. abs(sun_dir(3)) > tol ) then
            do cand_loop = -2, 2
              candidate = int(grid_x/period_val_x) + cand_loop
              ! 各領域についてループ（region = 1:雨樋, 2:カーテン１, 3:カーテン２）
              do region = 1, 3
                select case(region)
                case(1)
                  region_x_left = candidate * period_val_x - gutter_width/2.0_dp_kind
                  region_x_right = candidate * period_val_x + gutter_width/2.0_dp_kind
                  region_z_top = gutter_ztop
                  region_z_bottom = gutter_ztop - gutter_depth
                case(2)
                  region_x_left = candidate * period_val_x - curtain1_width/2.0_dp_kind
                  region_x_right = candidate * period_val_x + curtain1_width/2.0_dp_kind
                  region_z_top = gutter_ztop - gutter_depth
                  region_z_bottom = region_z_top - curtain1_thickness
                case(3)
                  region_x_left = candidate * period_val_x - curtain2_width/2.0_dp_kind
                  region_x_right = candidate * period_val_x + curtain2_width/2.0_dp_kind
                  region_z_top = gutter_ztop - gutter_depth - curtain1_thickness
                  region_z_bottom = region_z_top - curtain2_thickness
                end select

                ! --- 左側面との交点 ---
                t_left = (region_x_left - grid_x) / sun_dir(1)
                if ( t_left > 0.0_dp_kind ) then
                  z_left = grid_z + t_left * sun_dir(3)
                  if ( z_left >= region_z_bottom .and. z_left <= region_z_top ) then
                    shadow_curtain = 1
                    exit  ! 領域ループから脱出
                  end if
                end if

                ! --- 右側面との交点 ---
                t_right = (region_x_right - grid_x) / sun_dir(1)
                if ( t_right > 0.0_dp_kind ) then
                  z_right = grid_z + t_right * sun_dir(3)
                  if ( z_right >= region_z_bottom .and. z_right <= region_z_top ) then
                    shadow_curtain = 1
                    exit
                  end if
                end if

                ! --- 下側面との交点 ---
                if ( abs(sun_dir(3)) > tol ) then
                  t_bottom = (region_z_bottom - grid_z) / sun_dir(3)
                  if ( t_bottom > 0.0_dp_kind ) then
                    x_bottom = grid_x + t_bottom * sun_dir(1)
                    if ( x_bottom >= region_x_left .and. x_bottom <= region_x_right ) then
                      shadow_curtain = 1
                      exit
                    end if
                  end if
                end if
              end do  ! region loop
              if ( shadow_curtain == 1 ) exit
            end do  ! candidate loop
          end if



          !----- 柱遮蔽判定 -----
          shadow_pillar = 0
          if ( abs(sun_dir(2)) > tol ) then
            do offset_x = -1, 1
              candidate_x = int(grid_x/period_val_x) + offset_x
              cand_x = candidate_x * period_val_x
              do offset_y = -1, 1
                candidate_y = int(grid_y/period_val_y) + offset_y
                cand_y = candidate_y * period_val_y
                ! 平面 y = cand_y との交点を求める
                t_p = (cand_y - grid_y) / sun_dir(2)
                if ( t_p > 0.0_dp_kind ) then
                  x_int = grid_x + t_p * sun_dir(1)
                  z_int = grid_z + t_p * sun_dir(3)
                  if ( x_int >= (cand_x - pillar_width/2.0_dp_kind) .and. &
                       x_int <= (cand_x + pillar_width/2.0_dp_kind) ) then
                    if ( z_int >= 0.0_dp_kind .and. z_int <= gutter_ztop ) then
                      shadow_pillar = 1
                      exit
                    end if
                  end if
                end if
              end do
              if ( shadow_pillar == 1 ) exit
            end do
          end if

          shadow_flag = max(shadow_curtain, shadow_pillar)
          illum(ix,iy,iz) = (1.0_dp_kind - shadow_flag)*I_direct + I_diffuse

        end do
      end do
    end do

!900 continue

  end subroutine greenhouse_calc

  !--------------------------------------------------------------------
  ! 補助サブルーチン check_in (変更なし)
  !--------------------------------------------------------------------
  subroutine check_in(x_left, x_right, x_val, flag_int)
    implicit none
    integer, parameter :: dp_kind = kind(1.0d0)
    real(dp_kind), intent(in) :: x_left, x_right, x_val
    integer, intent(inout)   :: flag_int
    real(dp_kind) :: x_min, x_max
    x_min = min(x_left, x_right)
    x_max = max(x_left, x_right)
    if ( x_min <= x_val .and. x_val <= x_max ) then
       flag_int = 1
    end if
  end subroutine check_in

  !--------------------------------------------------------------------
  ! 関数 cos_vec2d (変更なし)
  !--------------------------------------------------------------------
  function cos_vec2d(v1, v2) result(cos_val)
    implicit none
    real(dp_kind), dimension(2), intent(in) :: v1, v2
    real(dp_kind) :: cos_val
    real(dp_kind) :: norm1, norm2
    norm1 = sqrt(v1(1)**2 + v1(2)**2)
    norm2 = sqrt(v2(1)**2 + v2(2)**2)
    if (norm1 > 0.0_dp_kind .and. norm2 > 0.0_dp_kind) then
      cos_val = (v1(1)*v2(1) + v1(2)*v2(2))/(norm1*norm2)
    else
      cos_val = 0.0_dp_kind
    end if
  end function cos_vec2d

  !--------------------------------------------------------------------
  ! 関数 cos_vec3d (変更なし)
  !--------------------------------------------------------------------
  function cos_vec3d(v1, v2) result(cos_val)
    implicit none
    real(dp_kind), dimension(3), intent(in) :: v1, v2
    real(dp_kind) :: cos_val
    real(dp_kind) :: norm1, norm2
    norm1 = sqrt(v1(1)**2 + v1(2)**2 + v1(3)**2)
    norm2 = sqrt(v2(1)**2 + v2(2)**2 + v2(3)**2)
    if (norm1 > 0.0_dp_kind .and. norm2 > 0.0_dp_kind) then
      cos_val = (v1(1)*v2(1) + v1(2)*v2(2) + v1(3)*v2(3))/(norm1*norm2)
    else
      cos_val = 0.0_dp_kind
    end if
  end function cos_vec3d

  !--------------------------------------------------------------------
  ! サブルーチン output_illum_3d (変更なし)
  !--------------------------------------------------------------------
  subroutine output_illum_3d(illumination, nx, ny, nz, x_low, x_up, y_low, y_up, z_low, z_up)
    implicit none
    integer, parameter :: dp_kind = kind(1.0d0)
    integer, intent(in) :: nx, ny, nz
    real(dp_kind), intent(in) :: x_low, x_up, y_low, y_up, z_low, z_up
    real(dp_kind), intent(in) :: illumination(nx,ny,nz)
    integer :: i, j, k
    real(dp_kind) :: dx, dy, dz, x_coord, y_coord, z_coord

    dx = (x_up - x_low) / real(nx - 1, dp_kind)
    dy = (y_up - y_low) / real(ny - 1, dp_kind)
    dz = (z_up - z_low) / real(nz - 1, dp_kind)

    open(unit=11, file="out.dat", status="unknown", action="write")
    do k = 1, nz
      z_coord = z_low + (k-1)*dz
      do j = 1, ny
        y_coord = y_low + (j-1)*dy
        do i = 1, nx
          x_coord = x_low + (i-1)*dx
          write(11, '(F8.3,1X,F8.3,1X,F8.3,1X,F10.3)') x_coord, y_coord, z_coord, illumination(i,j,k)
        end do
        write(11,*)
      end do
      write(11,*)
    end do
    close(11)
  end subroutine output_illum_3d

  !--------------------------------------------------------------------
  ! サブルーチン output_illum_2d (変更なし)
  !--------------------------------------------------------------------
  subroutine output_illum_2d(illum2d, nx, nz, x_low, x_up, z_low, z_up)
    implicit none
    integer, parameter :: dp_kind = kind(1.0d0)
    integer, intent(in) :: nx, nz
    real(dp_kind), intent(in) :: x_low, x_up, z_low, z_up
    real(dp_kind), intent(in) :: illum2d(nx,nz)
    integer :: i, k
    real(dp_kind) :: dx, dz, x_coord, z_coord

    dx = (x_up - x_low) / real(nx - 1, dp_kind)
    dz = (z_up - z_low) / real(nz - 1, dp_kind)

    open(unit=11, file="out.dat", status="unknown", action="write")
    do k = 1, nz
      z_coord = z_low + (k-1)*dz
      do i = 1, nx
         x_coord = x_low + (i-1)*dx
         write(11, '(F8.3,1X,e8.3,1X,e10.3)') x_coord, z_coord, illum2d(i,k)
      end do
      write(11,*)
    end do
    close(11)
  end subroutine output_illum_2d

  !--------------------------------------------------------------------
  ! サブルーチン SunPosition (変更なし)
  !--------------------------------------------------------------------
  subroutine SunPosition(lat, lon, n, t_local, altitude, azimuth)
    implicit none
    double precision, intent(in)  :: lat
    double precision, intent(in)  :: lon
    integer, intent(in)           :: n
    double precision, intent(in)  :: t_local
    double precision, intent(out) :: altitude
    double precision, intent(out) :: azimuth
    double precision :: pi, deg2rad, rad2deg
    double precision :: delta, delta_rad
    double precision :: B, E
    double precision :: L_std
    double precision :: t_solar
    double precision :: omega, omega_rad
    double precision :: lat_rad
    double precision :: alt_rad
    double precision :: az_rad, A_deg

    pi     = 4.0d0 * atan(1.0d0)
    deg2rad = pi / 180.0d0
    rad2deg = 180.0d0 / pi

    delta     = 23.45d0 * sin( (360.0d0/365.0d0 * (284.0d0 + n)) * deg2rad )
    delta_rad = delta * deg2rad

    B = (360.0d0/365.0d0 * (n - 81)) * deg2rad
    E = 9.87d0 * sin(2.0d0 * B) - 7.53d0 * cos(B) - 1.5d0 * sin(B)

    L_std   = 15.0d0 * dble(nint(lon/15.0d0))
    t_solar = t_local + (4.0d0 * (lon - L_std) + E) / 60.0d0

    omega     = 15.0d0 * (t_solar - 12.0d0)
    omega_rad = omega * deg2rad

    lat_rad = lat * deg2rad
    alt_rad = asin( sin(delta_rad) * sin(lat_rad) + &
                    cos(delta_rad) * cos(lat_rad) * cos(omega_rad) )
    altitude = alt_rad * rad2deg

    az_rad = atan2( -cos(delta_rad) * sin(omega_rad), &
                    sin(delta_rad) * cos(lat_rad) - cos(delta_rad) * sin(lat_rad) * cos(omega_rad) )
    A_deg  = az_rad * rad2deg
    azimuth = mod(A_deg + 180.0d0 + 180d0, 360.0d0)
  end subroutine SunPosition

  !--------------------------------------------------------------------
  ! 関数 day_of_year (変更なし)
  !--------------------------------------------------------------------
  function day_of_year(m, d) result(n)
    implicit none
    integer, intent(in) :: m, d
    integer :: n
    integer, dimension(12) :: days = (/31,28,31,30,31,30,31,31,30,31,30,31/)
    n = sum(days(1:m-1)) + d
  end function day_of_year

  !--------------------------------------------------------------------
  ! サブルーチン date_from_day (変更なし)
  !--------------------------------------------------------------------
  subroutine date_from_day(n, m, d)
    implicit none
    integer, intent(in) :: n
    integer, intent(out) :: m, d
    integer, dimension(12) :: days = (/31,28,31,30,31,30,31,31,30,31,30,31/)
    integer :: i, temp, n_mod
    n_mod = mod(n-1,365)+1
    temp = n_mod
    m = 1
    do i = 1, 12
       if (temp <= days(i)) then
          d = temp
          exit
       else
          temp = temp - days(i)
          m = m + 1
       end if
    end do
  end subroutine date_from_day

  !--------------------------------------------------------------------
  ! 関数 daymax (変更なし)
  !--------------------------------------------------------------------
  function daymax(month) result(days)
    implicit none
    integer, intent(in) :: month
    integer :: days
    integer, parameter :: dmax(12) = (/31,28,31,30,31,30,31,31,30,31,30,31/)
    if (month >= 1 .and. month <= 12) then
      days = dmax(month)
    else
      days = -1
    end if
  end function daymax

end module greenhouse_module


