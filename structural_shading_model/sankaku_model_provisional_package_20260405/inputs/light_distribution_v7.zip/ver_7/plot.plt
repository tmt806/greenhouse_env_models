set size square
set pm3d map interpolate 10,10

set isosamples 10, 10
set format cb "%.2f"
set format x "%.0f"
set format y "%.1f"

set cbtics 0.05 font "Helvetica,24"
set xlabel " <- W   E -> [m]" font "Helvetica, 24" offset 0, -2
set ylabel " Height [m]" font "Helvetica, 24" offset -4, 0
set cblabel " Illumination [-] " font "Helvetica, 24" rotate by 270 offset 7,0
set xrange [0:7.5]
set yrange [0:4]
set ytics font "Helvetica,24"
set xtics font "Helvetica,24"
set mxtics 2
set mytics 2
set cbrange [0.75:1]

unset key
set palette rgbformulae 22,13,-31
set style line  1 lw 1 lc rgb "white"
set style line  2 lw 1 lc rgb "white"
set style line  3 lw 1 lc rgb "white"
set style line  4 lw 1 lc rgb "white"
set style line  5 lw 1 lc rgb "white"
set style line  6 lw 1 lc rgb "white"
set style line  7 lw 1 lc rgb "white"
set style line  8 lw 1 lc rgb "white"
set style line  9 lw 1 lc rgb "white"
set style line 10 lw 1 lc rgb "white"

set contour

set cntrparam levels incremental 0, 0.1, 1

set style increment user
set palette maxcolors 10
sp "out.dat" u 1:2:3



